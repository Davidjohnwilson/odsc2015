Slides and Notebooks for Open Data Science Conference
=====================================================
Materials for the Scikit-learn tutorial at ODSC SF.
Please download the materials and install scikit-learn and the jupyter notebook to follow along.
Please use Jupyter / IPython in Version 4.0 or higher.
The tutorial requires scikit-learn 0.15 or higher (current is 0.17).

Please check back for changes to the material.
It is recommended to update right before the tutorial.
