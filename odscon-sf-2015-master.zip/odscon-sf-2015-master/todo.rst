update text example
get stuff from the data science course
look into the corporate part
make sure everything runs on python3
get rid of unimportant stuff, rethink structure
rework text data example
